# DigitalDetectives
agriculture iot 
