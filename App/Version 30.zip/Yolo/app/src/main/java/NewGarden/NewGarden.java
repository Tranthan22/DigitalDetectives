package NewGarden;

public class NewGarden {
    private String user, sensor_id, motor_id;
    public NewGarden(String user, String sensor_id, String motor_id){

        String user1 = this.user;
        String sensor_id1 = this.sensor_id;
        String motor_id1 = this.motor_id;

    }
}
