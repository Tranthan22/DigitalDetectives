package com.example.myapplication2.message;

import java.util.ArrayList;

public class Message_info {
    private ArrayList<String> notification;

    public ArrayList<String> getNotification() {
        return notification;
    }
}