package Device_info;

public class Update_list_info {
    private String user, garden_id, sensor_id, motor_id;
    public Update_list_info(String user, String garden_id, String sensor_id, String motor_id){
        String user1 = this.user;
        String garden_id1 = this.garden_id;
        String sensor_id1 = this.sensor_id;
        String motor_id1 = this.motor_id;
    }
}
