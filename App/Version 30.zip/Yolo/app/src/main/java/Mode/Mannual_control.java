package Mode;

public class Mannual_control {
    private String user, node_id, bump_1, bump_2, bump_3;
    public Mannual_control(String user, String node_id, String bump_1, String bump_2, String bump_3){
        String user2 = this.user;
        String node_id2 = this.node_id;
        String bump_12 = this.bump_1;
        String bump_22 = this.bump_2;
        String bump_32 = this.bump_3;
    }
}
