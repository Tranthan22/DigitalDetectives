package MainActivity;

public class Token {
    private String user, token;
    public Token(String user, String token){
        String user1 = this.user;
        String token1 = this.token;

    }
}
