package User_info;

public interface OnGetNodeInfoListener {
    void onGetNodeInfoSuccess(String[] node_info);

    void onGetNodeInfoError();
}
