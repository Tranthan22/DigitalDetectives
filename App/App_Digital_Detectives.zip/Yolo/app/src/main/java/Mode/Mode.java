package Mode;

public class Mode {
    private String user, node_id, node_auto;
    public Mode(String user,String node_id, String node_auto ){
        String user1 = this.user;
        String node_id1 = this.node_id;
        String node_auto1 = this.node_auto;

    }
    public String getMode(){
        return node_auto;
    }

}
