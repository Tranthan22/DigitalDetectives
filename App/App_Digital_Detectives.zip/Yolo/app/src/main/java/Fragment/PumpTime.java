package Fragment;

public class PumpTime {
    private String user, node_id, pump_time,daily_pump_time,air_warning,soil_warning,battery_warning,temp_warning;
    public PumpTime(String user, String node_id, String pump_time,String daily_pump_time, String air_warning
                    ,String soil_warning, String battery_warning, String temp_warning){

        String user1 = this.user;
        String node_id1  =this.node_id;
        String pump_time1 = this.pump_time;
        String daily_pump_time1 = this.daily_pump_time;
        String air_warning1 =this.air_warning;
        String soil_warning1 = this.soil_warning;
        String battery_warning1 =this.battery_warning;
        String temp_warning1 = this.temp_warning;
    }
}
