package User_info;

public interface OnGetNodeNameListener {
    void onGetNodeNameSuccess(String[] items);
    void onGetNodeNameError();
}
